import os


def _csv(value: str) -> tuple[str, ...]:
    return tuple(item.strip() for item in value.split(",") if item.strip())


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


LOCAL_DIFY_MOCK_HOST = os.getenv("LOCAL_DIFY_MOCK_HOST", os.getenv("MOCK_DIFY_HOST", "127.0.0.1"))
LOCAL_DIFY_MOCK_PORT = int(os.getenv("LOCAL_DIFY_MOCK_PORT", os.getenv("MOCK_DIFY_PORT", "18080")))
LOCAL_DIFY_MOCK_BASE_URL = f"http://{LOCAL_DIFY_MOCK_HOST}:{LOCAL_DIFY_MOCK_PORT}"
LOCAL_DIFY_MOCK_HEALTH_URL = f"{LOCAL_DIFY_MOCK_BASE_URL}/healthz"
USE_LOCAL_DIFY_MOCK = _env_bool("USE_LOCAL_DIFY_MOCK", True)
AUTO_START_LOCAL_DIFY_MOCK = _env_bool("AUTO_START_LOCAL_DIFY_MOCK", True)


# Feishu bot configuration.
FEISHU_APP_ID = os.getenv("FEISHU_APP_ID", "cli_a93bb2832db85bd9")
FEISHU_APP_SECRET = os.getenv("FEISHU_APP_SECRET", "R1cBtuseOzWwtwbdggINJgHvEEl6tlsB")
FEISHU_LOG_LEVEL = os.getenv("FEISHU_LOG_LEVEL", "DEBUG").upper()
FEISHU_REPLY_IN_THREAD = os.getenv("FEISHU_REPLY_IN_THREAD", "false").lower() == "true"
FEISHU_ACK_REACTION_EMOJI_TYPE = os.getenv("FEISHU_ACK_REACTION_EMOJI_TYPE", "DONE")
FEISHU_PLACEHOLDER_TEXT = os.getenv("FEISHU_PLACEHOLDER_TEXT", "正在处理中，请稍候...")
FEISHU_EMPTY_RESULT_TEXT = os.getenv("FEISHU_EMPTY_RESULT_TEXT", "工作流已结束，但没有返回可展示的文本结果。")
FEISHU_MAX_MESSAGE_CHARS = int(os.getenv("FEISHU_MAX_MESSAGE_CHARS", "28000"))

# Dify workflow configuration.
DIFY_WORKFLOW_PAGE_URL = os.getenv(
    "DIFY_WORKFLOW_PAGE_URL",
    f"{LOCAL_DIFY_MOCK_BASE_URL}/mock-workflow"
    if USE_LOCAL_DIFY_MOCK
    else "https://dify.mjutech.com/app/97a55098-0e74-42ed-bcc8-7af172e74d73/workflow",
)
DIFY_API_BASE_URL = os.getenv(
    "DIFY_API_BASE_URL",
    f"{LOCAL_DIFY_MOCK_BASE_URL}/v1" if USE_LOCAL_DIFY_MOCK else "https://dify.mjutech.com/v1",
)
DIFY_WORKFLOW_RUN_PATH = os.getenv("DIFY_WORKFLOW_RUN_PATH", "/workflows/run")
_dify_api_key = os.getenv("DIFY_API_KEY", os.getenv("DIFY_TOKEN", ""))
DIFY_API_KEY = _dify_api_key or ("local-test-key" if USE_LOCAL_DIFY_MOCK else "")
DIFY_QUERY_INPUT_KEYS = _csv(os.getenv("DIFY_QUERY_INPUT_KEYS", "query,text,message,user_query"))
DIFY_FIXED_INPUTS: dict[str, object] = {}
DIFY_REQUEST_TIMEOUT_SECONDS = int(os.getenv("DIFY_REQUEST_TIMEOUT_SECONDS", "180"))

# Runtime behavior.
MESSAGE_MAX_AGE_MS = int(os.getenv("MESSAGE_MAX_AGE_MS", "120000"))
MESSAGE_CACHE_SIZE = int(os.getenv("MESSAGE_CACHE_SIZE", "1000"))
STREAM_FIRST_UPDATE_MIN_CHARS = int(os.getenv("STREAM_FIRST_UPDATE_MIN_CHARS", "4"))
STREAM_UPDATE_INTERVAL_SECONDS = float(os.getenv("STREAM_UPDATE_INTERVAL_SECONDS", "0.35"))
STREAM_FORCE_UPDATE_INTERVAL_SECONDS = float(os.getenv("STREAM_FORCE_UPDATE_INTERVAL_SECONDS", "0.9"))
STREAM_UPDATE_MIN_CHARS = int(os.getenv("STREAM_UPDATE_MIN_CHARS", "24"))
FEISHU_STREAM_MAX_UPDATES = int(os.getenv("FEISHU_STREAM_MAX_UPDATES", "5"))
API_RETRY_TIMES = int(os.getenv("API_RETRY_TIMES", "3"))
API_RETRY_BASE_SECONDS = float(os.getenv("API_RETRY_BASE_SECONDS", "1.0"))
MAX_ERROR_BODY_CHARS = int(os.getenv("MAX_ERROR_BODY_CHARS", "1500"))

# Output shaping.
PREFERRED_OUTPUT_KEYS = _csv(os.getenv("PREFERRED_OUTPUT_KEYS", "answer,text,output,result,final_text"))
