from __future__ import annotations

import atexit
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import OrderedDict
from typing import Any
from urllib.parse import urlparse

import lark_oapi as lark
from lark_oapi.api.im.v1 import (
    CreateMessageReactionRequest,
    CreateMessageReactionRequestBody,
    CreateMessageRequest,
    CreateMessageRequestBody,
    Emoji,
    P2ImMessageReceiveV1,
    ReplyMessageRequest,
    ReplyMessageRequestBody,
    UpdateMessageRequest,
    UpdateMessageRequestBody,
)

import config


TEXT_MENTION_PATTERN = re.compile(r"@_user_\d+\s*")
PROCESSED_MESSAGES: "OrderedDict[str, float]" = OrderedDict()
PROCESSED_MESSAGES_LOCK = threading.Lock()
LOCAL_MOCK_PROCESS: subprocess.Popen[Any] | None = None


class BotRuntimeError(Exception):
    pass


class DifyRequestError(BotRuntimeError):
    def __init__(self, summary: str, detail: str = "") -> None:
        super().__init__(summary)
        self.summary = summary
        self.detail = detail


class FeishuRequestError(BotRuntimeError):
    def __init__(self, message: str, code: str = "") -> None:
        super().__init__(message)
        self.code = str(code or "")


def _lark_log_level() -> Any:
    return getattr(lark.LogLevel, config.FEISHU_LOG_LEVEL, lark.LogLevel.DEBUG)


def _trim_text(value: Any, limit: int) -> str:
    text = value if isinstance(value, str) else str(value)
    if len(text) <= limit:
        return text
    return text[: limit - 20] + "\n...[truncated]..."


def _trim_message_text(text: str) -> str:
    if len(text) <= config.FEISHU_MAX_MESSAGE_CHARS:
        return text
    suffix = "\n\n[内容过长，已截断]"
    allowed = max(0, config.FEISHU_MAX_MESSAGE_CHARS - len(suffix))
    return text[:allowed] + suffix


def _json_text_message(text: str) -> str:
    return json.dumps({"text": _trim_message_text(text)}, ensure_ascii=False)


def _decode_bytes(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="ignore")
    return str(value or "")


def _response_detail(response: Any) -> str:
    raw = getattr(getattr(response, "raw", None), "content", b"")
    return _trim_text(_decode_bytes(raw), config.MAX_ERROR_BODY_CHARS)


def _is_message_edit_limit_error(exc: Exception) -> bool:
    return isinstance(exc, FeishuRequestError) and exc.code == "230072"


def _is_local_mock_target() -> bool:
    parsed = urlparse(config.DIFY_API_BASE_URL)
    return parsed.hostname in {"127.0.0.1", "localhost"} and parsed.port == config.LOCAL_DIFY_MOCK_PORT


def _probe_local_mock() -> bool:
    request = urllib.request.Request(config.LOCAL_DIFY_MOCK_HEALTH_URL, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=1.5) as response:
            return 200 <= getattr(response, "status", 0) < 300
    except Exception:
        return False


def _stop_local_mock() -> None:
    global LOCAL_MOCK_PROCESS
    if LOCAL_MOCK_PROCESS is None:
        return
    if LOCAL_MOCK_PROCESS.poll() is None:
        LOCAL_MOCK_PROCESS.terminate()
        try:
            LOCAL_MOCK_PROCESS.wait(timeout=3)
        except subprocess.TimeoutExpired:
            LOCAL_MOCK_PROCESS.kill()
            LOCAL_MOCK_PROCESS.wait(timeout=3)
    LOCAL_MOCK_PROCESS = None


def _ensure_local_mock_running() -> None:
    global LOCAL_MOCK_PROCESS

    if not config.USE_LOCAL_DIFY_MOCK or not config.AUTO_START_LOCAL_DIFY_MOCK:
        return
    if not _is_local_mock_target():
        return
    if _probe_local_mock():
        return
    if LOCAL_MOCK_PROCESS is not None and LOCAL_MOCK_PROCESS.poll() is None:
        return

    mock_script = os.path.join(os.path.dirname(__file__), "mock_dify_server.py")
    env = os.environ.copy()
    env.setdefault("MOCK_DIFY_HOST", config.LOCAL_DIFY_MOCK_HOST)
    env.setdefault("MOCK_DIFY_PORT", str(config.LOCAL_DIFY_MOCK_PORT))
    env.setdefault("MOCK_DIFY_REQUIRE_AUTH", "true")

    lark.logger.info(
        "local mock dify is not running, starting %s on %s",
        mock_script,
        config.LOCAL_DIFY_MOCK_BASE_URL,
    )
    LOCAL_MOCK_PROCESS = subprocess.Popen(
        [sys.executable, mock_script],
        env=env,
        cwd=os.path.dirname(__file__),
    )

    for _ in range(20):
        if _probe_local_mock():
            atexit.register(_stop_local_mock)
            lark.logger.info("local mock dify is ready: %s", config.LOCAL_DIFY_MOCK_BASE_URL)
            return
        if LOCAL_MOCK_PROCESS.poll() is not None:
            break
        time.sleep(0.25)

    raise BotRuntimeError(f"failed to start local mock dify at {config.LOCAL_DIFY_MOCK_BASE_URL}")


def _raise_for_lark_failure(action: str, response: Any) -> Any:
    if response.success():
        return response
    raise FeishuRequestError(
        f"{action} failed: code={getattr(response, 'code', '')}, "
        f"msg={getattr(response, 'msg', '')}, "
        f"log_id={getattr(response, 'get_log_id', lambda: '')()} "
        f"body={_response_detail(response)}",
        code=str(getattr(response, "code", "") or ""),
    )


def _retry_lark_call(action: str, func):
    last_error: Exception | None = None
    for attempt in range(1, config.API_RETRY_TIMES + 1):
        try:
            return func()
        except Exception as exc:
            if _is_message_edit_limit_error(exc):
                raise exc
            last_error = exc
            lark.logger.error(
                "%s failed on attempt %s/%s: %s",
                action,
                attempt,
                config.API_RETRY_TIMES,
                exc,
                exc_info=True,
            )
            if attempt < config.API_RETRY_TIMES:
                time.sleep(config.API_RETRY_BASE_SECONDS * attempt)
    if last_error is None:
        raise FeishuRequestError(f"{action} failed with unknown error")
    raise last_error


def _should_skip_message(message_id: str, create_time_ms: int | None) -> bool:
    now_ms = int(time.time() * 1000)
    if create_time_ms and now_ms - create_time_ms > config.MESSAGE_MAX_AGE_MS:
        lark.logger.info("skip old message: %s", message_id)
        return True

    with PROCESSED_MESSAGES_LOCK:
        if message_id in PROCESSED_MESSAGES:
            lark.logger.info("skip duplicated message: %s", message_id)
            return True

        PROCESSED_MESSAGES[message_id] = time.time()
        while len(PROCESSED_MESSAGES) > config.MESSAGE_CACHE_SIZE:
            PROCESSED_MESSAGES.popitem(last=False)

    return False


def _normalize_query(raw_text: str) -> str:
    text = TEXT_MENTION_PATTERN.sub("", raw_text or "")
    return text.replace("\u00a0", " ").strip()


def _parse_text_message(message: Any) -> str:
    if message.message_type != "text":
        return ""
    try:
        content = json.loads(message.content or "{}")
    except json.JSONDecodeError as exc:
        raise BotRuntimeError(f"message content is not valid JSON: {exc}") from exc
    raw_text = content.get("text", "")
    if not isinstance(raw_text, str):
        raise BotRuntimeError(f"message content text field is invalid: {content}")
    return _normalize_query(raw_text)


def _sender_user_id(data: P2ImMessageReceiveV1) -> str:
    sender_id = getattr(getattr(data.event, "sender", None), "sender_id", None)
    for key in ("open_id", "user_id", "union_id"):
        value = getattr(sender_id, key, None)
        if value:
            return value
    return "unknown-user"


def _build_workflow_inputs(query: str) -> dict[str, object]:
    inputs: dict[str, object] = dict(config.DIFY_FIXED_INPUTS)
    for key in config.DIFY_QUERY_INPUT_KEYS:
        inputs[key] = query
    return inputs


def _format_dify_http_error(status: int, body: str) -> str:
    code = ""
    message = ""
    try:
        payload = json.loads(body)
        if isinstance(payload, dict):
            code = str(payload.get("code") or "")
            message = str(payload.get("message") or "")
    except json.JSONDecodeError:
        pass

    detail = f"HTTP {status}"
    if code:
        detail += f", code={code}"
    if message:
        detail += f", message={message}"
    if body:
        detail += f", body={_trim_text(body, config.MAX_ERROR_BODY_CHARS)}"
    return detail


def _iter_sse_events(response) -> Any:
    event_name = ""
    data_lines: list[str] = []

    while True:
        raw_line = response.readline()
        if not raw_line:
            if event_name or data_lines:
                yield _parse_sse_event(event_name, data_lines)
            break

        line = raw_line.decode("utf-8", errors="ignore").rstrip("\r\n")
        if not line:
            if event_name or data_lines:
                yield _parse_sse_event(event_name, data_lines)
                event_name = ""
                data_lines = []
            continue

        if line.startswith(":"):
            continue

        field, _, value = line.partition(":")
        value = value.lstrip(" ")
        if field == "event":
            event_name = value
        elif field == "data":
            data_lines.append(value)


def _parse_sse_event(event_name: str, data_lines: list[str]) -> dict[str, Any]:
    payload_text = "\n".join(data_lines).strip()
    if not payload_text:
        return {"event": event_name, "_raw": ""}
    if payload_text == "[DONE]":
        return {"event": event_name or "done", "_raw": payload_text}

    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError:
        return {"event": event_name, "_raw": payload_text}

    if isinstance(payload, dict):
        if event_name and "event" not in payload:
            payload["event"] = event_name
        payload["_raw"] = payload_text
        return payload

    return {"event": event_name, "data": payload, "_raw": payload_text}


def _extract_best_output_text(outputs: Any) -> str:
    if isinstance(outputs, str):
        return outputs.strip()
    if isinstance(outputs, list):
        parts = [_extract_best_output_text(item) for item in outputs]
        parts = [part for part in parts if part]
        return "\n".join(parts)
    if isinstance(outputs, dict):
        for key in config.PREFERRED_OUTPUT_KEYS:
            if key in outputs:
                preferred = _extract_best_output_text(outputs[key])
                if preferred:
                    return preferred
        if len(outputs) == 1:
            only_value = next(iter(outputs.values()))
            return _extract_best_output_text(only_value)
        return json.dumps(outputs, ensure_ascii=False, indent=2)
    return ""


def _dify_stream(query: str, user_identifier: str) -> Any:
    if not config.DIFY_API_KEY:
        raise DifyRequestError(
            "DIFY_API_KEY is empty",
            "config.py or env does not provide a Dify API key",
        )

    url = config.DIFY_API_BASE_URL.rstrip("/") + "/" + config.DIFY_WORKFLOW_RUN_PATH.lstrip("/")
    request_body = {
        "inputs": _build_workflow_inputs(query),
        "response_mode": "streaming",
        "user": user_identifier,
    }
    encoded_body = json.dumps(request_body, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=encoded_body,
        headers={
            "Authorization": f"Bearer {config.DIFY_API_KEY}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    lark.logger.info("start dify workflow stream: url=%s body=%s", url, request_body)

    try:
        with urllib.request.urlopen(request, timeout=config.DIFY_REQUEST_TIMEOUT_SECONDS) as response:
            for event in _iter_sse_events(response):
                yield event
    except urllib.error.HTTPError as exc:
        body = _decode_bytes(exc.read())
        raise DifyRequestError(
            "Dify workflow HTTP error",
            _format_dify_http_error(exc.code, body),
        ) from exc
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, socket.timeout):
            raise DifyRequestError(
                "Dify workflow timeout",
                f"socket timeout after {config.DIFY_REQUEST_TIMEOUT_SECONDS}s",
            ) from exc
        raise DifyRequestError("Dify workflow request failed", str(exc.reason)) from exc
    except socket.timeout as exc:
        raise DifyRequestError(
            "Dify workflow timeout",
            f"socket timeout after {config.DIFY_REQUEST_TIMEOUT_SECONDS}s",
        ) from exc


def _format_error_message(summary: str, detail: str = "") -> str:
    text = f"[错误] {summary}"
    if detail:
        text += f"\n{_trim_text(detail, config.MAX_ERROR_BODY_CHARS)}"
    return text


def _format_finished_status(data: dict[str, Any]) -> str:
    status = str(data.get("status") or "unknown")
    error = str(data.get("error") or "").strip()
    elapsed = data.get("elapsed_time")
    total_tokens = data.get("total_tokens")
    pieces = [f"status={status}"]
    if elapsed is not None:
        pieces.append(f"elapsed_time={elapsed}")
    if total_tokens is not None:
        pieces.append(f"total_tokens={total_tokens}")
    if error:
        pieces.append(f"error={error}")
    return ", ".join(pieces)


def _reply_text(message: Any, text: str, uuid_suffix: str) -> str:
    content = _json_text_message(text)

    def _reply() -> str:
        response = client.im.v1.message.reply(
            ReplyMessageRequest.builder()
            .message_id(message.message_id)
            .request_body(
                ReplyMessageRequestBody.builder()
                .content(content)
                .msg_type("text")
                .reply_in_thread(config.FEISHU_REPLY_IN_THREAD)
                .uuid(f"{message.message_id}-{uuid_suffix}")
                .build()
            )
            .build()
        )
        _raise_for_lark_failure("reply text message", response)
        return getattr(response.data, "message_id", "") or ""

    try:
        return _retry_lark_call("reply text message", _reply)
    except Exception as reply_error:
        lark.logger.error("reply message failed, fallback to chat create: %s", reply_error, exc_info=True)

    def _create() -> str:
        response = client.im.v1.message.create(
            CreateMessageRequest.builder()
            .receive_id_type("chat_id")
            .request_body(
                CreateMessageRequestBody.builder()
                .receive_id(message.chat_id)
                .msg_type("text")
                .content(content)
                .uuid(f"{message.message_id}-{uuid_suffix}-create")
                .build()
            )
            .build()
        )
        _raise_for_lark_failure("create text message", response)
        return getattr(response.data, "message_id", "") or ""

    return _retry_lark_call("create text message", _create)


def _update_text_message(message_id: str, text: str) -> None:
    content = _json_text_message(text)

    def _update() -> None:
        response = client.im.v1.message.update(
            UpdateMessageRequest.builder()
            .message_id(message_id)
            .request_body(
                UpdateMessageRequestBody.builder()
                .msg_type("text")
                .content(content)
                .build()
            )
            .build()
        )
        _raise_for_lark_failure("update text message", response)

    _retry_lark_call("update text message", _update)


def _create_text_message(chat_id: str, text: str, uuid_suffix: str) -> str:
    content = _json_text_message(text)

    def _create() -> str:
        response = client.im.v1.message.create(
            CreateMessageRequest.builder()
            .receive_id_type("chat_id")
            .request_body(
                CreateMessageRequestBody.builder()
                .receive_id(chat_id)
                .msg_type("text")
                .content(content)
                .uuid(uuid_suffix)
                .build()
            )
            .build()
        )
        _raise_for_lark_failure("create text message", response)
        return getattr(response.data, "message_id", "") or ""

    return _retry_lark_call("create text message", _create)


def _add_ack_reaction(message_id: str) -> None:
    def _create_reaction() -> None:
        response = client.im.v1.message_reaction.create(
            CreateMessageReactionRequest.builder()
            .message_id(message_id)
            .request_body(
                CreateMessageReactionRequestBody.builder()
                .reaction_type(
                    Emoji.builder()
                    .emoji_type(config.FEISHU_ACK_REACTION_EMOJI_TYPE)
                    .build()
                )
                .build()
            )
            .build()
        )
        _raise_for_lark_failure("create message reaction", response)

    _retry_lark_call("create message reaction", _create_reaction)


def _should_flush_text(
    current_text: str,
    last_sent_length: int,
    last_flush_at: float,
    stream_update_count: int,
) -> bool:
    if not current_text:
        return False
    pending_chars = len(current_text) - last_sent_length
    if pending_chars <= 0:
        return False
    if stream_update_count >= config.FEISHU_STREAM_MAX_UPDATES:
        return False

    elapsed = time.time() - last_flush_at
    if last_sent_length == 0:
        if pending_chars >= config.STREAM_FIRST_UPDATE_MIN_CHARS:
            return True
        return elapsed >= config.STREAM_FORCE_UPDATE_INTERVAL_SECONDS
    if pending_chars >= config.STREAM_UPDATE_MIN_CHARS and elapsed >= config.STREAM_UPDATE_INTERVAL_SECONDS:
        return True
    return elapsed >= config.STREAM_FORCE_UPDATE_INTERVAL_SECONDS


def _stream_dify_to_message(
    reply_message_id: str,
    chat_id: str,
    query: str,
    user_identifier: str,
    extra_notice: str = "",
) -> None:
    accumulated_text = ""
    last_sent_length = 0
    last_flush_at = time.time()
    workflow_finished = False
    update_error_note = ""
    stream_update_count = 0
    stream_updates_disabled = False

    for event in _dify_stream(query, user_identifier):
        event_name = str(event.get("event") or "")
        lark.logger.debug("dify stream event: %s", event_name or event)

        if event_name == "text_chunk":
            data = event.get("data") or {}
            chunk_text = data.get("text")
            if isinstance(chunk_text, str) and chunk_text:
                accumulated_text += chunk_text
                lark.logger.info(
                    "stream chunk received: reply_message_id=%s chunk_len=%s total_len=%s",
                    reply_message_id,
                    len(chunk_text),
                    len(accumulated_text),
                )
                if stream_updates_disabled:
                    continue
                if _should_flush_text(accumulated_text, last_sent_length, last_flush_at, stream_update_count):
                    try:
                        started_at = time.time()
                        _update_text_message(reply_message_id, accumulated_text)
                        elapsed_ms = int((time.time() - started_at) * 1000)
                        delta = len(accumulated_text) - last_sent_length
                        stream_update_count += 1
                        last_sent_length = len(accumulated_text)
                        # Count the Feishu update round-trip itself toward the next flush window.
                        last_flush_at = started_at
                        lark.logger.info(
                            "stream flush sent: reply_message_id=%s total_len=%s delta=%s elapsed_ms=%s count=%s",
                            reply_message_id,
                            last_sent_length,
                            delta,
                            elapsed_ms,
                            stream_update_count,
                        )
                    except Exception as exc:
                        if _is_message_edit_limit_error(exc):
                            stream_updates_disabled = True
                            update_error_note = "已达到飞书单条消息编辑次数上限，后续内容将通过新消息发送。"
                            lark.logger.warning(
                                "stream updates disabled after edit limit: reply_message_id=%s count=%s",
                                reply_message_id,
                                stream_update_count,
                            )
                        else:
                            update_error_note = f"流式更新失败: {exc}"
                            lark.logger.error(update_error_note, exc_info=True)
            continue

        if event_name == "workflow_finished":
            workflow_finished = True
            data = event.get("data") or {}
            if not accumulated_text:
                accumulated_text = _extract_best_output_text(data.get("outputs"))

            final_text = accumulated_text or config.FEISHU_EMPTY_RESULT_TEXT
            if str(data.get("status") or "") != "succeeded":
                final_text = (
                    f"{final_text}\n\n"
                    f"{_format_error_message('Dify workflow ended abnormally', _format_finished_status(data))}"
                ).strip()
            if update_error_note:
                final_text = f"{final_text}\n\n[提示] {update_error_note}"
            if extra_notice:
                final_text = f"{final_text}\n\n[提示] {extra_notice}"

            if stream_updates_disabled:
                _create_text_message(
                    chat_id,
                    final_text,
                    f"{reply_message_id}-final-create",
                )
            elif final_text != accumulated_text or last_sent_length != len(accumulated_text):
                _update_text_message(reply_message_id, final_text)
            break

        if event_name in {
            "workflow_started",
            "node_started",
            "node_finished",
            "ping",
            "tts_message",
            "tts_message_end",
        }:
            continue

        lark.logger.warning("unknown dify event: %s", event.get("_raw") or event)

    if not workflow_finished:
        final_text = accumulated_text or _format_error_message(
            "Dify stream closed unexpectedly",
            "stream ended before workflow_finished event",
        )
        if extra_notice:
            final_text = f"{final_text}\n\n[提示] {extra_notice}"
        if stream_updates_disabled:
            _create_text_message(chat_id, final_text, f"{reply_message_id}-unexpected-close")
        else:
            _update_text_message(reply_message_id, final_text)
        raise DifyRequestError(
            "Dify stream closed unexpectedly",
            "stream ended before workflow_finished event",
        )


def do_p2_im_message_receive_v1(data: P2ImMessageReceiveV1) -> None:
    message = data.event.message
    message_id = message.message_id or ""
    create_time_ms = None
    try:
        create_time_ms = int(message.create_time)
    except (TypeError, ValueError):
        create_time_ms = None

    lark.logger.info(
        "receive message: message_id=%s chat_id=%s type=%s",
        message_id,
        message.chat_id,
        message.message_type,
    )

    if not message_id or _should_skip_message(message_id, create_time_ms):
        return

    reaction_error = ""
    try:
        _add_ack_reaction(message_id)
    except Exception as exc:
        reaction_error = str(exc)
        lark.logger.error("ack reaction failed: %s", reaction_error, exc_info=True)

    try:
        query = _parse_text_message(message)
    except Exception as exc:
        error_text = _format_error_message("消息解析失败", str(exc))
        if reaction_error:
            error_text += f"\n[提示] 表情回复失败: {_trim_text(reaction_error, 300)}"
        _reply_text(message, error_text, "parse-error")
        return

    if message.message_type != "text":
        text = _format_error_message("暂不支持该消息类型", f"message_type={message.message_type}")
        if reaction_error:
            text += f"\n[提示] 表情回复失败: {_trim_text(reaction_error, 300)}"
        _reply_text(message, text, "unsupported")
        return

    if not query:
        text = _format_error_message("消息内容为空", "未转发到 Dify workflow")
        if reaction_error:
            text += f"\n[提示] 表情回复失败: {_trim_text(reaction_error, 300)}"
        _reply_text(message, text, "empty")
        return

    reply_message_id = _reply_text(message, config.FEISHU_PLACEHOLDER_TEXT, "placeholder")
    if not reply_message_id:
        raise FeishuRequestError("placeholder message created but message_id is empty")

    user_identifier = _sender_user_id(data)

    try:
        _stream_dify_to_message(reply_message_id, message.chat_id, query, user_identifier, reaction_error)
    except DifyRequestError as exc:
        error_text = _format_error_message(exc.summary, exc.detail)
        if reaction_error:
            error_text += f"\n[提示] 表情回复失败: {_trim_text(reaction_error, 300)}"
        _update_text_message(reply_message_id, error_text)
    except Exception as exc:
        lark.logger.error("unexpected handler error: %s", exc, exc_info=True)
        error_text = _format_error_message("处理消息时发生未预期错误", str(exc))
        if reaction_error:
            error_text += f"\n[提示] 表情回复失败: {_trim_text(reaction_error, 300)}"
        _update_text_message(reply_message_id, error_text)


event_handler = (
    lark.EventDispatcherHandler.builder("", "")
    .register_p2_im_message_receive_v1(do_p2_im_message_receive_v1)
    .build()
)


client = (
    lark.Client.builder()
    .app_id(config.FEISHU_APP_ID)
    .app_secret(config.FEISHU_APP_SECRET)
    .log_level(_lark_log_level())
    .build()
)

ws_client = lark.ws.Client(
    config.FEISHU_APP_ID,
    config.FEISHU_APP_SECRET,
    event_handler=event_handler,
    log_level=_lark_log_level(),
)


def main() -> None:
    _ensure_local_mock_running()
    lark.logger.info("starting Feishu bot with workflow page %s", config.DIFY_WORKFLOW_PAGE_URL)
    ws_client.start()


if __name__ == "__main__":
    main()
